#!/bin/bash
echo "Установка WINE..."
sudo apt update
sudo apt upgrade
sudo apt dist-upgrade
sudo apt install ia32-libs
wget https://easyastra.ru/files/soft/wine_7.13-0-astra-se17_amd64.deb
sudo dpkg -i wine_7.13-0-astra-se17_amd64.deb
rm wine_7.13-0-astra-se17_amd64.deb
sudo ln -s /opt/wine-7.13/bin/wine /usr/bin/wine
sudo apt install ca-certificates libmspack0 cabextract
wget https://raw.githubusercontent.com/Winetricks/winetricks/master/src/winetricks
chmod +x winetricks
sudo mv winetricks /usr/bin/
export WINE=/opt/wine-7.13/bin/wine
/opt/wine-7.13/bin/winecfg
sudo /opt/wine-7.13/bin/winecfg
exit
