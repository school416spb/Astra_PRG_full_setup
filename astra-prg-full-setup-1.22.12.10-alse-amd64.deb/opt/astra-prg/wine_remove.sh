#!/bin/bash
echo "Удаление WINE..."
sudo apt remove wine-7.13
sudo rm /usr/bin/wine
sudo rm /usr/bin/winetricks
sudo rm -r $HOME/.wine/
sudo rm -r /root/.wine  
