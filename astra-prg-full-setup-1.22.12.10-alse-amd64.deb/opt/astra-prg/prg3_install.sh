#!/bin/bash
echo "Установка серверной части ПАРАГРАФ 3..."
sudo nmcli networking off
cd $HOME/paragraf_linux/
./install_server.sh
sudo chown firebird:firebird /var/bases/prg3/*.FDB
sudo chown firebird:firebird /var/bases/prg3/*.sh
./install_server.sh
sudo chown firebird:firebird /var/bases/prg3/*.FDB
sudo chown firebird:firebird /var/bases/prg3/*.sh
sudo nmcli networking on
