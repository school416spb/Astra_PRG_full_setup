#!/bin/bash
echo "Удаление DATAGATE..."
sudo service wine-datagate stop
sudo rm /etc/init.d/wine-datagate
sudo rm -r /root/.wine/drive_c/ProgramData/IVC/
sudo rm -r /root/.wine/drive_c/Program\ Files\ \(x86\)/IVC/
