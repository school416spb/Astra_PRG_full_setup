#!/bin/bash
echo "Установка DATAGATE..."
sudo nmcli networking off
cd $HOME/DG/
sudo chmod 777 datagate-install.sh
sudo ./datagate-install.sh
sudo /etc/init.d/wine-datagate start
sudo nmcli networking on
