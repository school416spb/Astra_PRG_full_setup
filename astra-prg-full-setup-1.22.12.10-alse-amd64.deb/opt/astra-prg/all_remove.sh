#!/bin/bash
echo "Удаление АИСУ ПАРАГРАФ 3..."

sudo nmcli networking off

sudo service wine-datagate stop
sudo rm /etc/init.d/wine-datagate
sudo rm -r /root/.wine/drive_c/ProgramData/IVC/
sudo rm -r /root/.wine/drive_c/Program\ Files\ \(x86\)/IVC

echo "Пароль пользователя SYSDBA: "
read PASSWORD

mkdir $HOME/db_prg_backup_remove
sudo /opt/firebird/bin/gbak -b -v -t -USER SYSDBA -PASS $PASSWORD /var/bases/prg3/BASE.FDB $HOME/db_prg_backup_remove/BASE.FBK
sudo /opt/firebird/bin/gbak -b -v -t -USER SYSDBA -PASS $PASSWORD /var/bases/prg3/BIN.FDB $HOME/db_prg_backup_remove/BIN.FBK
sudo /opt/firebird/bin/gbak -b -v -t -USER SYSDBA -PASS $PASSWORD /var/bases/prg3/BLOB.FDB $HOME/db_prg_backup_remove/BLOB.FBK
sudo /opt/firebird/bin/gbak -b -v -t -USER SYSDBA -PASS $PASSWORD /var/bases/prg3/DOC.FDB $HOME/db_prg_backup_remove/DOC.FBK

sudo chown firebird:firebird $HOME/db_prg_backup_remove/*.FBK

sudo rm -r /var/bases/

sudo service firebird stop
sudo rm -r /opt/firebird/

sudo apt remove wine-7.13
sudo rm /usr/bin/wine
sudo rm /usr/bin/winetricks
sudo rm -r $HOME/.wine/
sudo rm -r /root/.wine

sudo nmcli networking on
