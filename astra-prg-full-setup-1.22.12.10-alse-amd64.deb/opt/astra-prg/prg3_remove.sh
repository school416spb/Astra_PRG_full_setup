#!/bin/bash
echo "Удаление серверной части ПАРАГРАФ 3..."

echo "Пароль пользователя SYSDBA: "
read PASSWORD

mkdir $HOME/db_prg_backup_remove
sudo /opt/firebird/bin/gbak -b -v -t -USER SYSDBA -PASS $PASSWORD /var/bases/prg3/BASE.FDB $HOME/db_prg_backup_remove/BASE.FBK
sudo /opt/firebird/bin/gbak -b -v -t -USER SYSDBA -PASS $PASSWORD /var/bases/prg3/BIN.FDB $HOME/db_prg_backup_remove/BIN.FBK
sudo /opt/firebird/bin/gbak -b -v -t -USER SYSDBA -PASS $PASSWORD /var/bases/prg3/BLOB.FDB $HOME/db_prg_backup_remove/BLOB.FBK
sudo /opt/firebird/bin/gbak -b -v -t -USER SYSDBA -PASS $PASSWORD /var/bases/prg3/DOC.FDB $HOME/db_prg_backup_remove/DOC.FBK

sudo chown firebird:firebird $HOME/db_prg_backup_remove/*.FBK

sudo rm -r /var/bases/
