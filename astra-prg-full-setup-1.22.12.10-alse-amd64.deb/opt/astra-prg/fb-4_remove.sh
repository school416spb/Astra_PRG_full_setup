#!/bin/bash
echo "Удаление СУБД FireBird 4..."
sudo service firebird stop
sudo rm -r /opt/firebird/

