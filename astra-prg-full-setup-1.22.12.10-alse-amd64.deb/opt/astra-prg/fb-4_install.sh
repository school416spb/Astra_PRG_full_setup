#!/bin/bash
echo "Установка СУБД FireBird 4..."
sudo apt install libtommath1;
wget https://easyastra.ru/files/soft/fb/Firebird-4.0.1.2692-0.amd64.tar.gz
tar xvzf Firebird-4.0.1.2692-0.amd64.tar.gz
cd Firebird-4.0.1.2692-0.amd64/
sudo ./install.sh
cd ..
wget https://easyastra.ru/files/soft/fb/firebird.conf
sudo mv firebird.conf /opt/firebird/
rm -r Firebird-4.0.1.2692-0.amd64/
rm Firebird-4.0.1.2692-0.amd64.tar.gz
sudo service firebird stop
sudo service firebird start
